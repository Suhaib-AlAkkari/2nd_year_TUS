package roguelike;

import java.awt.*;

public class Trap extends Item
{
    private Effect trapEffect;
    public Effect trapEffect() { return trapEffect; }
    public void setTrapEffect(Effect effect) { this.trapEffect = effect; }

    public Trap(char glyph, Color color, String name)
    {
        super(glyph, color, name);
    }
}
