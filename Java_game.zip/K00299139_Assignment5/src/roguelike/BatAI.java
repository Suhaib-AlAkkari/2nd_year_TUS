package roguelike;

public class BatAI extends CreatureAI {

    public BatAI(Creature creature) {
        super(creature);
    }

    public void onUpdate(){
        wander();
        wander();
    }
}