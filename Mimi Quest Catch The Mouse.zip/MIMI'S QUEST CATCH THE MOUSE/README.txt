To lunch the game:

Download MIMI'S QUEST CATCH THE MOUSE and unzip it
Go to: https://editor.construct.net/?startTour
Select Open > File then select MIMI'S QUEST CATCH THE MOUSE.cpp
On top of the screen make sure 'Intro' is selected then click the little arrow 'Preview layout'

*************************************************************************************************

Controls:

Arrow keys for movement
B to interact with objects
E to use items in the inventory

*************************************************************************************************

Objectives

Lure the mouse out and catch it

Good luck and have fun

*************************************************************************************************

By Suhaib Al Akkari
K00299139