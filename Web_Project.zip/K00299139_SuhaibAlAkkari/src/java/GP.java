/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

/**
 *
 * @author student
 */
@WebServlet(urlPatterns = {"/GP"})
public class GP extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
    String gpName;
    String gpAddress;
    String gpPhone;
    Connection conn;
    PreparedStatement prepStat;
    Statement stat;
    
    public void init() throws ServletException {

        String url = "jdbc:mysql://localhost:3306/";
        String dbName = "appdev";
        String userName = "root";
        String password = "";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = (Connection) DriverManager.getConnection(url + dbName, userName, password);
            stat = (Statement) conn.createStatement();
            System.out.println("Connected");
            stat.execute("CREATE TABLE IF NOT EXISTS gp"
                    + "(gp_name CHAR(40) PRIMARY KEY, gp_address CHAR(40), gp_phone INT(10))");
            System.out.println("After table create");

        } catch (Exception e) {
            System.err.println(e);
        }

    } // end of init() method
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        boolean loggedIn = false;

        // check if the user is logged in
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) { // check all cookies
                if ("user".equals(cookie.getName())) { // if a cookie called "user" is found
                    loggedIn = true;
                    break;
                }
            }
        }

        // if not logged in go to login page
        if (!loggedIn) {
            response.sendRedirect("login.html");
            return;
        }
        
        init();
        gpName = request.getParameter("gp_name");
        gpAddress = request.getParameter("gp_address");
        gpPhone = request.getParameter("gp_phone");
        // insert items intpo the gp table
        try {
            String query = "INSERT INTO gp VALUES (?,?,?)";
            prepStat = (PreparedStatement) conn.prepareStatement(query);
            prepStat.setString(1, gpName);
            prepStat.setString(2, gpAddress);
            prepStat.setString(3, gpPhone);
            prepStat.executeUpdate();
            System.out.println("After insert");
            try (PrintWriter out = response.getWriter()) {
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<title>Servlet GP</title>");
                out.println("</head>");
                out.println("<body>");
                out.println("<br><br><br><h1>Data inserted successfully</h1>");
                out.println("<br> <br> <br> <a href=\"index.html\">Home</a>");
                out.println("</body>");
                out.println("</html>");
            }

        } catch (Exception e) {
            System.err.println(e);
            try (PrintWriter out = response.getWriter()) {
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<title>Servlet GP</title>");
                out.println("</head>");
                out.println("<body>");
                out.println("<br><br><br><h1>Error on insert</h1>");
                out.println("<br> <br> <br> <a href=\"index.html\">Home</a>");
                out.println("</body>");
                out.println("</html>");
            }

        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
