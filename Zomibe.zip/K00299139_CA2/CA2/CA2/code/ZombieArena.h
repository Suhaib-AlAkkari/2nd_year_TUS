#pragma once
#include "Zombie.h"

using namespace sf;

int createBackground(VertexArray& rVA, IntRect arena); // to create the background
Zombie* createHorde(int numZombies, IntRect arena, bool bossWave); // to create a horde of zombies
