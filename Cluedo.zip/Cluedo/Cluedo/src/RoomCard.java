// Suhaib Al Akkari
// room card class

public class RoomCard  extends Card // (Inheritance)
{
    // default constructor
    public RoomCard()
    {
        super("room");
    }

    // para constructor
    public RoomCard(String name)
    {
        super(name);
    }
}
