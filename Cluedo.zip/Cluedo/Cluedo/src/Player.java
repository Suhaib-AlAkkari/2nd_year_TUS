// Suhaib Al Akkari
// player class

import javax.swing.*;

public class Player implements CardUser  // (Inheritance / Interfaces)
{
    // all variables are private (Encapsulation)
    private String name; // player name
    private Card[] playerCards; // player cards (Arrays) (Aggregation)
    private int playerRow; // player x position
    private int playerCol; // player y position
    // player cards
    private static JLabel[] lblPlayerCards = { new JLabel(""), // (Arrays)
                                            new JLabel(""),
                                            new JLabel(""),
                                            new JLabel(""),
                                            new JLabel(""),
                                            new JLabel(""),
                                            new JLabel(""),
                                            new JLabel(""),
                                            new JLabel(""),
                                            new JLabel(""),
                                            new JLabel(""),
                                            new JLabel(""),
                                            new JLabel(""),
                                            new JLabel(""),
                                            new JLabel(""),
                                            new JLabel(""),
                                            new JLabel(""),
                                            new JLabel(""),
                                            new JLabel(""),
                                            new JLabel(""),
                                            new JLabel(""),
                                            new JLabel(""),
                                            new JLabel(""),
                                            new JLabel(""),
                                            new JLabel(""),
                                            new JLabel(""),
                                            new JLabel("")
                                            };


    // default constructor
    public Player()
    {
        this.name = "player";
        playerCards = new Card[27];
        this.playerRow = 0;
        this.playerCol = 0;
    }

    // para constructor
    public Player(String name, int row, int col)
    {
        this.name = name;
        playerCards = new Card[27];
        this.playerRow = row;
        this.playerCol = col;
    }

    // set player name
    public void setName(String name)
    {
        this.name = name;
    }

    // get player name
    public String getName()
    {
        return name;
    }

    // set player cards
    public void setCards(Card[] playerCards)
    {
        this.playerCards = playerCards;
    }

    // get player cards
    public Card[] getCards()
    {
        return playerCards;
    }

    // set player row
    public void setRow(int playerRow)
    {
        this.playerRow = playerRow;
    }

    // get player row
    public int getRow()
    {
        return playerRow;
    }

    // set player col
    public void setCol(int playerCol)
    {
        this.playerCol = playerCol;
    }

    // get player col
    public int getCol()
    {
        return playerCol;
    }

    // set player cards label
    public void setLblPlayerCards(String cardName, int i)
    {
        lblPlayerCards[i].setText(cardName);
    }

    // get player cards label
    public JLabel getLblPlayerCards(int i)
    {
        return lblPlayerCards[i];
    }
}
