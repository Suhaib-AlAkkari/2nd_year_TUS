// Suhaib Al Akkari
// abstract class card

public abstract class Card // (Abstraction / Abstract Classes )
{
    private String name; // card name (Encapsulation)

    // default constructor
    public Card()
    {
        this.name = "Card";
    }

    // para constructor
    public Card(String name)
    {
        this.name = name;
    }

    // get name
    public String getName()
    {
        return name;
    }

    // set name
    public void setName(String name)
    {
        this.name = name;
    }

    // to string
    @Override
    public String toString()
    {
        return "Card: " + name;
    }
}

