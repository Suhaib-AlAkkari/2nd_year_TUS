// Suhaib Al Akkari
// dice class

import java.util.Random;

public class Dice
{
    private int dice; // (Encapsulation)

    // default constructor, no need for para constructor
    public Dice()
    {
        dice = 1;
    }

    // set dice
    public void setDice(int dice)
    {
        this.dice = dice;
    }

    // get dice
    public int getDice()
    {
        return dice;
    }

    // roll the dice method
    public int rollDice()
    {
        Random rand = new Random();

        int min = 1; // minimum dice value
        int max = 6; // maximum dice value

        dice = rand.nextInt(max - min +1) + min;

        return dice;
    }

    // to string
    public String toString()
    {
        return "Dice roll: " + dice;
    }
}