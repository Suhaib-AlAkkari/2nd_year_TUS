// Suhaib Al Akkari
// weapon card class

public class WeaponCard extends Card // (Inheritance)
{
    // default constructor
    public WeaponCard()
    {
        super("weapon");
    }

    // para constructor
    public WeaponCard(String name)
    {
        super(name);
    }
}
