// Suhaib Al Akkari
// card used interface

public interface CardUser // (Interfaces)
{
    // all methods are abstract by default (Abstraction)
    void setName(String name); // set name

    String getName(); // get name

    void setCards(Card[] cards); // set cards

    Card[] getCards(); // get cards

    void setRow(int row); // set x position

    void setCol(int col); // set y position

    int getRow(); // get x position

    int getCol(); // get y position
}
