// Suhaib Al Akkari
// Game

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.FileWriter;
import java.io.IOException;

public class Game
{
    // all variables are private (Encapsulation)
    private Board board; // board object (Composition)
    private Dice dice; // dice object
    private Player playerSherlock; // first player Sherlock (Composition)
    private Player playerDrWatson; // second player Dr Watson (Composition)
    private Player currentPlayer; // current player turn (Composition)
    private JButton[][] buttons; // 2D array of Jbutton objects
    private int turnsCount; // counter for the number of turns
    private JLabel lblTurnsCount; // JLabel to display the number of turns
    private JButton btnDice; // JButton to roll the dice
    private JLabel lblCurrentPlayer; // JLabel to display the current player
    private JLabel lblDice; // JLabel to display the dice roll
    private JLabel lblMoves; // JLabel to display the number of moves left
    private JTextField tfGuess1; // JTextField for the guessing input
    private JTextField tfGuess2; // JTextField for the guessing input
    private JTextField tfGuess3; // JTextField for the guessing input
    private JButton btnGuess; // JButton to check if the guess is correct
    private JPanel pnlInterface; // JPanel for the interface
    private JFrame boardFrame; // JFrame for the board display
    private JFrame interfaceFrame; // JFrame for interface display
    private boolean diceRoll; // boolean to allow only 1 dice roll per turn

    // default constructor
    public Game()
    {
        playerSherlock = new Player("Sherlock" , 2, 8);
        playerDrWatson = new Player("Dr.Watson", 6, 0);
        board = new Board(playerSherlock, playerDrWatson);
        dice = new Dice();
        currentPlayer = playerSherlock;
        buttons = new JButton[board.getROWS()][board.getCOLS()];
        turnsCount = 5;
        lblTurnsCount = new JLabel("Number of turns left: " + turnsCount);
        btnDice = new JButton("Dice");
        lblCurrentPlayer = new JLabel("Current player: " + currentPlayer.getName());
        lblDice = new JLabel("Dice roll: ");
        lblMoves = new JLabel("Number of Moves: ");
        tfGuess1 = new JTextField(10);
        tfGuess2 = new JTextField(10);
        tfGuess3 = new JTextField(10);
        btnGuess = new JButton("Guess");
        pnlInterface = new JPanel();
        boardFrame = new JFrame("Cluedo");
        interfaceFrame = new JFrame("Interface");
        diceRoll = true;
        initilizeBoard();
        initilizeInterface();
    }

    // initilize the board
    private void initilizeBoard()
    {
        boardFrame.setLayout(new GridLayout(board.getROWS(), board.getCOLS())); // set layout
        boardFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // exit on clicking x

        // setting up the board
        for (int row = 0; row < board.getROWS(); row++)
        {
            for (int col = 0; col < board.getROWS(); col++)
            {
                buttons[row][col] = new JButton(board.getCell(row, col)); // create new JButton objects
                buttons[row][col].setFont(new Font("Arial", Font.PLAIN, 12)); // font and font size

                int finalRow = row;
                int finalCol = col;

                // action listener to handle button click
                buttons[row][col].addActionListener(new ActionListener()
                {
                    @Override
                    public void actionPerformed(ActionEvent e)
                    {
                        handleButtonClick(finalRow, finalCol);
                    }
                });

                boardFrame.add(buttons[row][col]); // adding the buttons to the frame
            }
        }

        // set up the rooms with different colours
        for (int i = 0; i < board.getROWS(); i += 4)
        {
            for (int j = 0; j < board.getROWS(); j += 4)
            {
                buttons[i][j].setBackground(new Color(100, 200, 100));
            }
        }

        boardFrame.setSize(1400, 900); // size of the board frame
        boardFrame.setVisible(true); // set the frame to visible
    }

    // initilize the interface (includes dice, cards and guessing)
    private void initilizeInterface()
    {
        interfaceFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // exit on clicking x

        // action listener to roll the dice
        btnDice.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                if (diceRoll) // check if the player can roll the dice
                {
                    dice.rollDice(); // rolling the dice
                    lblDice.setText(String.valueOf(dice)); // setting the label value to the dice roll
                    lblMoves.setText("Number of Moves: " + String.valueOf(dice.getDice())); // setting the label value to the dice roll
                    diceRoll = false; // to make sure the player cannot roll the dice again
                }
            }
        });

        // action listener to handle the guessing
        btnGuess.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                if (board.checkWin(tfGuess1.getText(), tfGuess2.getText(), tfGuess3.getText())) // check if the guess is correct
                {
                    JOptionPane.showMessageDialog(boardFrame, "Correct, you won!"); // display winning message
                    System.exit(0); // close the game
                }
                else // if not correct
                {
                    JOptionPane.showMessageDialog(boardFrame, "Incorrect guess!"); // display incorrect message
                }
            }
        });

        pnlInterface.add(lblTurnsCount); // add turns count label to interface panel
        pnlInterface.add(lblCurrentPlayer); // add current player label to interface panel
        pnlInterface.add(btnDice); // add dice button to interface panel
        pnlInterface.add(lblDice); // add dice label to interface panel
        pnlInterface.add(lblMoves); // add moves label to interface panel
        // add cards labels to interface panel
        for (int i = 0; i < 27; i++)
        {
            pnlInterface.add(currentPlayer.getLblPlayerCards(i));
        }
        pnlInterface.add(tfGuess1); // add guess label to interface panel
        pnlInterface.add(tfGuess2); // add guess label to interface panel
        pnlInterface.add(tfGuess3); // add guess label to interface panel
        pnlInterface.add(btnGuess); // add guess button to interface panel
        interfaceFrame.add(pnlInterface); // add interface panel to interface frame

        interfaceFrame.setSize(200, 500); // set the size of the interface frame
        interfaceFrame.setVisible(true); // set the interface frame to visible
    }

    // handle button click in the board frame
    private void handleButtonClick(int row, int col)
    {
        if (board.move(currentPlayer, currentPlayer.getRow(), currentPlayer.getCol(), row, col) && dice.getDice() != 0) // if the move is valid
        {
            buttons[currentPlayer.getRow()][currentPlayer.getCol()].setText(String.valueOf("")); // clear the current player position
            buttons[row][col].setText(String.valueOf(currentPlayer.getName())); // set the new player position
            currentPlayer.setRow(row); // update the player x to the new position
            currentPlayer.setCol(col); // update the player y to the new position

            dice.setDice(dice.getDice() - 1); // subtract from the number of moves left
            lblMoves.setText("Number of Moves: " + String.valueOf(dice.getDice())); // update the number of moves left label

            if (dice.getDice() == 0 && turnsCount != 0) // if the player used all their moves
            {
                currentPlayer = (currentPlayer == playerSherlock) ? playerDrWatson : playerSherlock; // change current player to the other player
                lblCurrentPlayer.setText("Current player: " + currentPlayer.getName()); // update the current player label
                diceRoll = true; // allow them to roll the dice

                // of the player is Sherlock, subtract from the total turns allowed (each player is allowed 5 turns only)
                if (currentPlayer.getName().equals("Sherlock"))
                {
                    turnsCount--; // subtract from the total turns
                }
                lblTurnsCount.setText("Number of turns left: " + turnsCount); // update the tuns label
            }
        }
        else // if the move is invalid
        {
            JOptionPane.showMessageDialog(boardFrame, "This move is not valid!"); // display invalid message
        }

        // writing to a text file
        try
        {
            FileWriter statsFile = new FileWriter("src/stats.txt"); // new file writer object
            statsFile.write("Player: " + currentPlayer.getName() + " || Row: " + currentPlayer.getRow() + " || Col: " + currentPlayer.getCol()); // writing the player name + position
            statsFile.close(); // close
        }
        catch (IOException e) // exception handling
        {
            throw new RuntimeException(e);
        }
    }

    // main method
    public static void main(String[] args)
    {
        Game game = new Game(); // create a new game object
    }
}
