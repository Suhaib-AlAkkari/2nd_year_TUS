// Suhaib Al Akkari
// character card class

public class CharacterCard extends Card // (Inheritance)
{
    // default constructor
    public CharacterCard()
    {
        super("character");
    }

    // para constructor
    public CharacterCard(String name)
    {
        super(name);
    }
}
