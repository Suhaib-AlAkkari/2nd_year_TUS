// Suhaib Al Akkari
// deck class

import java.util.*;

public class Deck
{
    // all variables are private (Encapsulation)
    private Card[] deckCharacterCards; // deck character cards (Arrays) (Composition)
    private Card[] deckWeaponCards; // deck weapon cards (Arrays) (Composition)
    private Card[] deckRoomCards; // deck room cards (Arrays) (Composition)
    private static int counter = 0; // counter to distribute the cards

    private Card[] envelope = new Card[3]; // envelop cards (Arrays) (Aggregation)

    // default constructor, no para constructor needed
    public Deck()
    {
        deckCharacterCards = new CharacterCard[10]; // array for character cards (Polymorphism)
        deckWeaponCards = new WeaponCard[10]; // array for weapon cards (Polymorphism)
        deckRoomCards = new RoomCard[10]; // array for room cards (Polymorphism)

        // 10 character cards, Sherlock Holmes villains
        deckCharacterCards[0] = new CharacterCard("James Moriaty");
        deckCharacterCards[1] = new CharacterCard("Eurus Holmes");
        deckCharacterCards[2] = new CharacterCard("Charles Augustus Milverton");
        deckCharacterCards[3] = new CharacterCard("Irene Adler");
        deckCharacterCards[4] = new CharacterCard("Jack Stapleton");
        deckCharacterCards[5] = new CharacterCard("Dr Bob Franklad");
        deckCharacterCards[6] = new CharacterCard("Vivian Norbury");
        deckCharacterCards[7] = new CharacterCard("Culverton Smith");
        deckCharacterCards[8] = new CharacterCard("Jeff Hope");
        deckCharacterCards[9] = new CharacterCard("Jack the Ripper");

        // 10 weapon cards
        deckWeaponCards[0] = new WeaponCard("Pipe");
        deckWeaponCards[1] = new WeaponCard("Wrench");
        deckWeaponCards[2] = new WeaponCard("Dagger");
        deckWeaponCards[3] = new WeaponCard("Revolver");
        deckWeaponCards[4] = new WeaponCard("Rope");
        deckWeaponCards[5] = new WeaponCard("Candlestick");
        deckWeaponCards[6] = new WeaponCard("Poison");
        deckWeaponCards[7] = new WeaponCard("Bomb");
        deckWeaponCards[8] = new WeaponCard("Hands");
        deckWeaponCards[9] = new WeaponCard("Fire");

        // 10 room cards
        deckRoomCards[0] = new RoomCard("Hall");
        deckRoomCards[1] = new RoomCard("Study");
        deckRoomCards[2] = new RoomCard("Kitchen");
        deckRoomCards[3] = new RoomCard("Ballroom");
        deckRoomCards[4] = new RoomCard("Billiard");
        deckRoomCards[5] = new RoomCard("Library");
        deckRoomCards[6] = new RoomCard("Dining");
        deckRoomCards[7] = new RoomCard("Conservatory");
        deckRoomCards[8] = new RoomCard("Lounge");
        deckRoomCards[9] = new RoomCard("Living");

        // shuffle the cards
        shuffleDeck();

        // evvelope cards
        envelope[0] = deckCharacterCards[9];
        envelope[1] = deckWeaponCards[9];
        envelope[2] = deckRoomCards[9];
    }

    // get envelope cards
    public Card[] getEnvelope()
    {
        return envelope;
    }

    // shuffle deck
    public void shuffleDeck()
    {
        List<Card> shuffleCharacterList = Arrays.asList(deckCharacterCards); // convert character cards to a list (Collections)
        List<Card> shuffleWeaponList = Arrays.asList(deckWeaponCards); // convert weapon cards to a list (Collections)
        List<Card> shuffleRoomList = Arrays.asList(deckRoomCards); // convert room cards to a list (Collections)

        Collections.shuffle(shuffleCharacterList); // shuffle character cards
        Collections.shuffle(shuffleWeaponList); // shuffle weapon cards
        Collections.shuffle(shuffleRoomList); // shuffle room cards

        deckCharacterCards = shuffleCharacterList.toArray(new Card[10]); // convert character cards back to Card[] array
        deckWeaponCards = shuffleWeaponList.toArray(new Card[10]); // convert weapon cards back to Card[] array
        deckRoomCards = shuffleRoomList.toArray(new Card[10]); // convert room cards back to Card[] array
    }

    // give 3 cards to a card user *NOT FINISHED*
    public Card[] give3Cards()
    {
        Card[] cards = new Card[3]; // array of card objects

        cards[0] = deckCharacterCards[counter]; // character card
        cards[1] = deckWeaponCards[counter]; // weapon card
        cards[2] = deckRoomCards[counter]; // room card

        counter++; // static counter

        return cards;
    }
}
