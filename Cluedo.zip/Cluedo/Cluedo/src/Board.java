// Suhaib Al Akkari
// board class

public class Board
{
    // all variables are private (Encapsulation)
    private String[][] board; // board 2D array (Arrays)
    private final int ROWS = 9; // number of rows
    private final int COLS = 9; // number of cols
    private Deck deck = new Deck(); // new deck object (Aggregation)
    private static int cardCounter = 0; // player card counter
    private Card[] envelope = new Card[3]; // envelope (Arrays) (Aggregation)

    // the 9 rooms in the game
    private final Room[] ROOM = { new Room("Hall", 8, 4), // (Arrays) (Aggregation)
                                    new Room("Study", 8, 8),
                                    new Room("Kitchen", 0, 0),
                                    new Room("Ballroom", 0, 4),
                                    new Room("Billiard", 4, 4),
                                    new Room("Library", 4, 8),
                                    new Room("Dining", 4, 0),
                                    new Room("Conservatory", 0, 8),
                                    new Room("Lounge", 8, 0)
                                };

    // para constructor
    public Board(Player playerSherlock, Player playerDrWatson)
    {
        board = new String[ROWS][COLS];

        // setting all the fields to empty
        for (int i = 0; i < ROWS; i++)
        {
            for (int j = 0; j < COLS; j++)
            {
                board[i][j] = "";
            }
        }

        // setting the fixed room's fields
        setRoomsPosition(ROOM);

        // setting the players position
        board[playerSherlock.getRow()][playerSherlock.getCol()] = playerSherlock.getName();
        board[playerDrWatson.getRow()][playerDrWatson.getCol()] = playerDrWatson.getName();

        // giving each room 3 cards
        for (int i = 0; i < ROOM.length; i++)
        {
            ROOM[i].setCards(deck.give3Cards());
        }

        // getting the envelope cards
        envelope = deck.getEnvelope();

        // display the correct answer in the console
        for (int i = 0; i < envelope.length; i++)
        {
            System.out.println("envelope " + envelope[i]);
        }
    }

    // setting rooms position on the board
    private void setRoomsPosition(Room[] room)
    {
        board[room[0].getRow()][room[0].getCol()] = room[0].getName();
        board[room[1].getRow()][room[1].getCol()] = room[1].getName();
        board[room[2].getRow()][room[2].getCol()] = room[2].getName();
        board[room[3].getRow()][room[3].getCol()] = room[3].getName();
        board[room[4].getRow()][room[4].getCol()] = room[4].getName();
        board[room[5].getRow()][room[5].getCol()] = room[5].getName();
        board[room[6].getRow()][room[6].getCol()] = room[6].getName();
        board[room[7].getRow()][room[7].getCol()] = room[7].getName();
        board[room[8].getRow()][room[8].getCol()] = room[8].getName();
    }

    // get the number of rows
    public int getROWS()
    {
        return ROWS;
    }

    // get the number of cols
    public int getCOLS()
    {
        return COLS;
    }

    // get the string value of a cell
    public String getCell(int row, int col)
    {
        return board[row][col];
    }

    // check win method
    public boolean checkWin(String guess1, String guess2, String guess3)
    {
        boolean guess1Check = false; // first card guess
        boolean guess2Check = false; // second card guess
        boolean guess3Check = false; // third card guess

        if (!guess1.equals(guess2) && !guess1.equals(guess3) && !guess2.equals(guess3)) // if the guessing fields are not equal
        {
            for (int i = 0; i < envelope.length; i++)
            {
                if (guess1.equals(envelope[i].getName())) // if first guess is correct
                {
                    guess1Check = true;
                }

                if (guess2.equals(envelope[i].getName())) // if second guess is correct
                {
                    guess2Check = true;
                }

                if (guess2.equals(envelope[i].getName())) // if third guess is correct
                {
                    guess3Check = true;
                }
            }
        }

        // if all guesses are correct
        if (guess1Check && guess2Check && guess3Check)
        {
            return true;
        }

        return false;
    }

    // handling movement
    public boolean move(Player player, int currentRow, int currentCol, int row, int col)
    {
        // if the position is +-1 x or +-1 y
        if (row <= currentRow + 1 && row >= currentRow - 1 && col <= currentCol + 1 && col >= currentCol - 1)
        {
            for (int i = 0; i < ROOM.length; i++)
            {
                // of the player is in a room
                if (player.getRow() == ROOM[i].getRow() && player.getCol() == ROOM[i].getCol())
                {
                    for (int j = 0; j < 3; j++)
                    {
                        // if room cards are not empty
                        if (!ROOM[i].getCardName(j).equals(""))
                        {
                            player.setLblPlayerCards(ROOM[i].getCardName(j), cardCounter); // give the player the room card
                            ROOM[i].setCardName("", j); // set the room card to empty
                            cardCounter++; // increment the card counter
                        }
                    }
                }
            }

            // set the player name to the new position
            board[row][col] = player.getName();
            return true;
        }

        return false;
    }
}
