// Suhaib Al Akkari
// room class

public class Room implements CardUser // (Inheritance / Interfaces)
{
    // all variables are private (Encapsulation)
    private String name; // room name
    private Card[] roomCards; // the cards inside the room (Arrays) (Aggregation)
    private int roomRow; // rool x position
    private int roomCol; // room y position

    // default constructor
    public Room()
    {
        this.name = "room";
        roomCards = new Card[3];
        this.roomRow = 0;
        this.roomCol = 0;
    }

    // para constructor
    public Room(String name, int row, int col)
    {
        this.name = name;
        roomCards = new Card[3];
        this.roomRow = row;
        this.roomCol = col;
    }

    // get name
    public String getName()
    {
        return name;
    }

    // set name
    public void setName(String name)
    {
        this.name = name;
    }

    // get room cards
    public Card[] getCards()
    {
        return roomCards;
    }

    // get card name
    public String getCardName(int i)
    {
        return roomCards[i].getName();
    }

    // set card name
    public void setCardName(String name, int i)
    {
        roomCards[i].setName(name);
    }

    // set room cards
    public void setCards(Card[] roomCards)
    {
        this.roomCards = roomCards;
    }

    // set room row
    public void setRow(int playerRow)
    {
        this.roomRow = playerRow;
    }

    // get room row
    public int getRow()
    {
        return roomRow;
    }

    // set room col
    public void setCol(int playerCol)
    {
        this.roomCol = playerCol;
    }

    // get room col
    public int getCol()
    {
        return roomCol;
    }
}
